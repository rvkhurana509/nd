﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace IPHTickets.Data.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Ameo",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    logid = table.Column<string>(nullable: true),
                    recipient_id = table.Column<string>(nullable: true),
                    issent = table.Column<byte>(nullable: false),
                    isdelivered = table.Column<byte>(nullable: false),
                    isread = table.Column<byte>(nullable: false),
                    text = table.Column<string>(nullable: true),
                    from = table.Column<string>(nullable: true),
                    timestamp = table.Column<string>(nullable: true),
                    type = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: false),
                    enq_code = table.Column<int>(nullable: false),
                    uid = table.Column<string>(nullable: true),
                    direction = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ameo", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Ticket",
                columns: table => new
                {
                    ticketid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ticketname = table.Column<string>(nullable: true),
                    ticketassignid = table.Column<string>(nullable: true),
                    ticketstatus = table.Column<string>(nullable: true),
                    ticketdatetime = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ticket", x => x.ticketid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Ameo");

            migrationBuilder.DropTable(
                name: "Ticket");
        }
    }
}
