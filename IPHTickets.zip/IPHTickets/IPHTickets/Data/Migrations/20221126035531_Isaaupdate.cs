﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IPHTickets.Data.Migrations
{
    public partial class Isaaupdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "trackingob",
                schema: "Identity",
                table: "Isaa");

            migrationBuilder.AddColumn<string>(
                name: "difftrack",
                schema: "Identity",
                table: "Isaa",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "difftrack",
                schema: "Identity",
                table: "Isaa");

            migrationBuilder.AddColumn<string>(
                name: "trackingob",
                schema: "Identity",
                table: "Isaa",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
