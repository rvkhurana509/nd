﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IPHTickets.Data.Migrations
{
    public partial class Isaachanges : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "memoryunsual",
                schema: "Identity",
                table: "Isaa");

            migrationBuilder.AlterColumn<string>(
                name: "trackingob",
                schema: "Identity",
                table: "Isaa",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "memory",
                schema: "Identity",
                table: "Isaa",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "memory",
                schema: "Identity",
                table: "Isaa");

            migrationBuilder.AlterColumn<string>(
                name: "trackingob",
                schema: "Identity",
                table: "Isaa",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "memoryunsual",
                schema: "Identity",
                table: "Isaa",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
