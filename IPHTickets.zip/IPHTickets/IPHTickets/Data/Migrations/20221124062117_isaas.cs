﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace IPHTickets.Data.Migrations
{
    public partial class isaas : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Isaa",
                schema: "Identity",
                columns: table => new
                {
                    patientid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(nullable: false),
                    bill = table.Column<string>(nullable: false),
                    gender = table.Column<string>(nullable: false),
                    date = table.Column<DateTime>(nullable: false),
                    dob = table.Column<string>(nullable: false),
                    Age = table.Column<string>(nullable: false),
                    exam = table.Column<string>(nullable: false),
                    pooreye = table.Column<string>(nullable: false),
                    smile = table.Column<string>(nullable: false),
                    aloof = table.Column<string>(nullable: false),
                    reach = table.Column<string>(nullable: false),
                    relate = table.Column<string>(nullable: false),
                    respond = table.Column<string>(nullable: false),
                    engage = table.Column<string>(nullable: false),
                    turn = table.Column<string>(nullable: false),
                    relation = table.Column<string>(nullable: false),
                    emotional = table.Column<string>(nullable: false),
                    exaggerated = table.Column<string>(nullable: false),
                    stimulate = table.Column<string>(nullable: false),
                    fear = table.Column<string>(nullable: false),
                    agitated = table.Column<string>(nullable: false),
                    speech = table.Column<string>(nullable: false),
                    language = table.Column<string>(nullable: false),
                    streotyped = table.Column<string>(nullable: false),
                    eholalic = table.Column<string>(nullable: false),
                    squeal = table.Column<string>(nullable: false),
                    initiate = table.Column<string>(nullable: false),
                    jargon = table.Column<string>(nullable: false),
                    pronoun = table.Column<string>(nullable: false),
                    grasp = table.Column<string>(nullable: false),
                    manner = table.Column<string>(nullable: false),
                    inanimate = table.Column<string>(nullable: false),
                    hyper = table.Column<string>(nullable: false),
                    behave = table.Column<string>(nullable: false),
                    temper = table.Column<string>(nullable: false),
                    injury = table.Column<string>(nullable: false),
                    sameness = table.Column<string>(nullable: false),
                    stimuli = table.Column<string>(nullable: false),
                    stare = table.Column<string>(nullable: false),
                    trackingob = table.Column<string>(nullable: false),
                    unusual = table.Column<string>(nullable: false),
                    pain = table.Column<string>(nullable: false),
                    tasting = table.Column<string>(nullable: false),
                    inconsistent = table.Column<string>(nullable: false),
                    delay = table.Column<string>(nullable: false),
                    memoryunsual = table.Column<string>(nullable: false),
                    savant = table.Column<string>(nullable: false),
                    noaut = table.Column<string>(nullable: false),
                    mildaut = table.Column<string>(nullable: false),
                    moderate = table.Column<string>(nullable: false),
                    severe = table.Column<string>(nullable: false),
                    remark = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Isaa", x => x.patientid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Isaa",
                schema: "Identity");
        }
    }
}
