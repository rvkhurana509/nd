﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IPHTickets.Data.Migrations
{
    public partial class call : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CallDTO",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    agentphonenumber = table.Column<string>(nullable: true),
                    disposition = table.Column<string>(nullable: true),
                    callerconfaudiofile = table.Column<string>(nullable: true),
                    transferredto = table.Column<string>(nullable: true),
                    apikey = table.Column<string>(nullable: true),
                    did = table.Column<string>(nullable: true),
                    starttime = table.Column<string>(nullable: true),
                    callduration = table.Column<string>(nullable: true),
                    endtime = table.Column<string>(nullable: true),
                    confduration = table.Column<string>(nullable: true),
                    customerstatus = table.Column<string>(nullable: true),
                    timetoanswer = table.Column<string>(nullable: true),
                    monitorucid = table.Column<string>(nullable: true),
                    agentid = table.Column<string>(nullable: true),
                    agentstatus = table.Column<string>(nullable: true),
                    location = table.Column<string>(nullable: true),
                    fallbackrule = table.Column<string>(nullable: true),
                    campaignstatus = table.Column<string>(nullable: true),
                    callerid = table.Column<string>(nullable: true),
                    duration = table.Column<string>(nullable: true),
                    status = table.Column<string>(nullable: true),
                    agentuniqueid = table.Column<string>(nullable: true),
                    username = table.Column<string>(nullable: true),
                    hangupby = table.Column<string>(nullable: true),
                    audiofile = table.Column<string>(nullable: true),
                    phonename = table.Column<string>(nullable: true),
                    transfertype = table.Column<string>(nullable: true),
                    dialstatus = table.Column<string>(nullable: true),
                    campaignname = table.Column<string>(nullable: true),
                    uui = table.Column<string>(nullable: true),
                    agentname = table.Column<string>(nullable: true),
                    skill = table.Column<string>(nullable: true),
                    dialednumber = table.Column<string>(nullable: true),
                    comments = table.Column<string>(nullable: true),
                    createddate = table.Column<string>(nullable: true),
                    enq_code = table.Column<string>(nullable: true),
                    isused = table.Column<string>(nullable: true),
                    type = table.Column<string>(nullable: true),
                    vendor = table.Column<string>(nullable: true),
                    dprid = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CallDTO", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Calls",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    agentphonenumber = table.Column<string>(nullable: true),
                    disposition = table.Column<string>(nullable: true),
                    callerconfaudiofile = table.Column<string>(nullable: true),
                    transferredto = table.Column<string>(nullable: true),
                    apikey = table.Column<string>(nullable: true),
                    did = table.Column<string>(nullable: true),
                    starttime = table.Column<string>(nullable: true),
                    callduration = table.Column<string>(nullable: true),
                    endtime = table.Column<string>(nullable: true),
                    confduration = table.Column<string>(nullable: true),
                    customerstatus = table.Column<string>(nullable: true),
                    timetoanswer = table.Column<string>(nullable: true),
                    monitorucid = table.Column<string>(nullable: true),
                    agentid = table.Column<string>(nullable: true),
                    agentstatus = table.Column<string>(nullable: true),
                    location = table.Column<string>(nullable: true),
                    fallbackrule = table.Column<string>(nullable: true),
                    campaignstatus = table.Column<string>(nullable: true),
                    callerid = table.Column<string>(nullable: true),
                    duration = table.Column<string>(nullable: true),
                    status = table.Column<string>(nullable: true),
                    agentuniqueid = table.Column<string>(nullable: true),
                    username = table.Column<string>(nullable: true),
                    hangupby = table.Column<string>(nullable: true),
                    audiofile = table.Column<string>(nullable: true),
                    phonename = table.Column<string>(nullable: true),
                    transfertype = table.Column<string>(nullable: true),
                    dialstatus = table.Column<string>(nullable: true),
                    campaignname = table.Column<string>(nullable: true),
                    uui = table.Column<string>(nullable: true),
                    agentname = table.Column<string>(nullable: true),
                    skill = table.Column<string>(nullable: true),
                    dialednumber = table.Column<string>(nullable: true),
                    comments = table.Column<string>(nullable: true),
                    createddate = table.Column<string>(nullable: true),
                    enq_code = table.Column<string>(nullable: true),
                    isused = table.Column<string>(nullable: true),
                    type = table.Column<string>(nullable: true),
                    vendor = table.Column<string>(nullable: true),
                    dprid = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Calls", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TicketsDTO",
                columns: table => new
                {
                    ticketid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ticketname = table.Column<string>(nullable: true),
                    ticketassignid = table.Column<string>(nullable: true),
                    ticketstatus = table.Column<string>(nullable: true),
                    ticketdatetime = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TicketsDTO", x => x.ticketid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CallDTO");

            migrationBuilder.DropTable(
                name: "Calls");

            migrationBuilder.DropTable(
                name: "TicketsDTO");
        }
    }
}
