﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace IPHTickets.Data.Migrations
{
    public partial class naddtn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Otassesment",
                schema: "Identity",
                columns: table => new
                {
                    FormID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PatientName = table.Column<string>(nullable: false),
                    BillCode = table.Column<int>(nullable: false),
                    Age = table.Column<string>(nullable: false),
                    Sex = table.Column<string>(nullable: false),
                    Address = table.Column<string>(nullable: false),
                    DOB = table.Column<DateTime>(nullable: false),
                    School = table.Column<string>(nullable: true),
                    Class = table.Column<string>(nullable: true),
                    Dominance = table.Column<string>(nullable: true),
                    Diagnosis = table.Column<string>(nullable: true),
                    DOA = table.Column<DateTime>(nullable: false),
                    Concern = table.Column<string>(nullable: true),
                    Birthhistory = table.Column<string>(nullable: true),
                    WalkSpeak = table.Column<string>(nullable: true),
                    Medicalconditions = table.Column<string>(nullable: true),
                    OnMedication = table.Column<string>(nullable: true),
                    Hospitalizations = table.Column<string>(nullable: true),
                    Familytype = table.Column<string>(nullable: true),
                    Profoffather = table.Column<string>(nullable: true),
                    Profofmother = table.Column<string>(nullable: true),
                    sibling = table.Column<string>(nullable: true),
                    Ageofsibling = table.Column<string>(nullable: true),
                    Schoolofsibling = table.Column<string>(nullable: true),
                    Primarycaregiver = table.Column<string>(nullable: true),
                    Historyifpreexist = table.Column<string>(nullable: true),
                    Anytreatmentearlier = table.Column<string>(nullable: true),
                    Restrictinchildjoint = table.Column<string>(nullable: true),
                    Hyperflexibile = table.Column<string>(nullable: true),
                    Overallstrength = table.Column<string>(nullable: true),
                    Catching = table.Column<string>(nullable: true),
                    Balance = table.Column<string>(nullable: true),
                    Throwing = table.Column<string>(nullable: true),
                    Jumpingonfloor = table.Column<string>(nullable: true),
                    Clapping = table.Column<string>(nullable: true),
                    Negotiating = table.Column<string>(nullable: true),
                    Jumpfromhieght = table.Column<string>(nullable: true),
                    Cycling = table.Column<string>(nullable: true),
                    Standoneleg = table.Column<string>(nullable: true),
                    Kicking = table.Column<string>(nullable: true),
                    Hopingonleg = table.Column<string>(nullable: true),
                    Feelhotcoldpain = table.Column<string>(nullable: true),
                    Eyehandcoordination = table.Column<string>(nullable: true),
                    Handfunction = table.Column<string>(nullable: true),
                    Recognizepeople = table.Column<string>(nullable: true),
                    Recognizeplace = table.Column<string>(nullable: true),
                    Orientedtotime = table.Column<string>(nullable: true),
                    Attention = table.Column<string>(nullable: true),
                    Distraction = table.Column<string>(nullable: true),
                    Rememberdob = table.Column<string>(nullable: true),
                    Commandfollow = table.Column<string>(nullable: true),
                    Understandbeforespeak = table.Column<string>(nullable: true),
                    Understandsocialbehaviour = table.Column<string>(nullable: true),
                    Vision = table.Column<string>(nullable: true),
                    Hearing = table.Column<string>(nullable: true),
                    Abletospeak = table.Column<string>(nullable: true),
                    Preferredmodeofcom = table.Column<string>(nullable: true),
                    Understandspokenofother = table.Column<string>(nullable: true),
                    Mathematics = table.Column<string>(nullable: true),
                    Aplhabet = table.Column<string>(nullable: true),
                    Writing = table.Column<string>(nullable: true),
                    Reading = table.Column<string>(nullable: true),
                    Calculation = table.Column<string>(nullable: true),
                    Identifycommoncolor = table.Column<string>(nullable: true),
                    Identifycommonshape = table.Column<string>(nullable: true),
                    Identifymatching = table.Column<string>(nullable: true),
                    Identifycategoryoffruit = table.Column<string>(nullable: true),
                    Cluttereddrawer = table.Column<string>(nullable: true),
                    Conceptofsize = table.Column<string>(nullable: true),
                    Descriminateobject = table.Column<string>(nullable: true),
                    Identifyimage = table.Column<string>(nullable: true),
                    Drawgeometricalfig = table.Column<string>(nullable: true),
                    Abletosearchobject = table.Column<string>(nullable: true),
                    Identifyrightandleft = table.Column<string>(nullable: true),
                    Identifyallbodypart = table.Column<string>(nullable: true),
                    Makenewfriend = table.Column<string>(nullable: true),
                    Playaloneorgroup = table.Column<string>(nullable: true),
                    Hittingself = table.Column<string>(nullable: true),
                    Abletodress = table.Column<string>(nullable: true),
                    Abletofeed = table.Column<string>(nullable: true),
                    AbletoToilet = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Otassesment", x => x.FormID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Otassesment",
                schema: "Identity");
        }
    }
}
