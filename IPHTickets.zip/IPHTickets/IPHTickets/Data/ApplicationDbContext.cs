﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using IPHTickets.Models;
using IPHTickets.DTO;
using Microsoft.AspNetCore.Identity;

namespace IPHTickets.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<IPHTickets.Models.Ticket> Ticket { get; set; }
        public DbSet<IPHTickets.Models.Ameo> Ameo { get; set; }
        public DbSet<IPHTickets.DTO.TicketsDTO> TicketsDTO { get; set; }
        public DbSet<IPHTickets.Models.Calls> Calls { get; set; }
        public DbSet<IPHTickets.DTO.CallDTO> CallDTO { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.HasDefaultSchema("Identity");
            builder.Entity<IdentityUser>(entity =>
            {
                entity.ToTable(name: "User");
            });
            builder.Entity<IdentityRole>(entity =>
            {
                entity.ToTable(name: "Role");
            });
            builder.Entity<IdentityUserRole<string>>(entity =>
            {
                entity.ToTable("UserRoles");
            });
            builder.Entity<IdentityUserClaim<string>>(entity =>
            {
                entity.ToTable("UserClaims");
            });
            builder.Entity<IdentityUserLogin<string>>(entity =>
            {
                entity.ToTable("UserLogins");
            });
            builder.Entity<IdentityRoleClaim<string>>(entity =>
            {
                entity.ToTable("RoleClaims");
            });
            builder.Entity<IdentityUserToken<string>>(entity =>
            {
                entity.ToTable("UserTokens");
            });
        }
        public DbSet<IPHTickets.Models.Otassesment> Otassesment { get; set; }
        public DbSet<IPHTickets.Models.Isaa> Isaa { get; set; }
    }
}
