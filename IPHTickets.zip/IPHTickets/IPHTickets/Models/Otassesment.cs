﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IPHTickets.Models
{
    public class Otassesment
    {
        [Key] 
        [Required]
        public int FormID { get; set; }
        [Required]
        public string PatientName { get; set; }
        [Required]
        [DisplayName("Enter Bill No.")]
        public int BillCode { get; set; }

        [Required]
        public string Age { get; set; }

        [Required]
        public string Sex { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public DateTime DOB { get; set; }

        
        public string School { get; set; }

       
        public string Class { get; set; }
        public string Dominance { get; set; }
        public string Diagnosis { get; set; }
        [Required]
        public DateTime DOA { get; set; }
        
        [DisplayName("Chief Complaints/Concerns")]
        public string Concern { get; set; }

        [DisplayName("Birth history of the child including the type of delivery, full term or pre mature, birth weight, birth cry, any history of Jaundice?")]
        public string Birthhistory { get; set; }

        [DisplayName("Whether the child started walking and speaking on time?")]
        public string WalkSpeak { get; set; }

        [DisplayName("Does the child have any co morbid medical conditions like hypertension, diabetes, epilepsy or tuberculosis? If yes, please specify")]
        public string Medicalconditions { get; set; }

        [DisplayName("Since how long is the child on medication for any reason?")]
        public string OnMedication { get; set; }

        [DisplayName("Are there any prior hospitalizations and surgeries? If yes, please specify.")]
        public string Hospitalizations { get; set; }
        [DisplayName("Nuclear/joint family")]
        public string Familytype { get; set; }

        [DisplayName("Profession of Father")]
        public string Profoffather { get; set; }

        [DisplayName("Profession of Mother")]
        public string Profofmother { get; set; }
        [DisplayName("Number of siblings")]
        public string sibling { get; set; }
        [DisplayName("Age of siblings")]
        public string Ageofsibling { get; set; }

        [DisplayName("School of siblings")]
        public string Schoolofsibling { get; set; }
        [DisplayName("Primary caregiver of the child ")]
        public string Primarycaregiver { get; set; }

        [DisplayName("History of the same/similar condition in the family (maternal/paternal) if yes, then specify")]
        public string Historyifpreexist { get; set; }
        [DisplayName("Has the child undergone any treatment earlier/visited any psychiatrist or therapist? Kindly mention the complete course of therapies/medical advice from the beginning")]
        public string Anytreatmentearlier { get; set; }
        
        [DisplayName("Do you find any restriction in the child’s joints? ")]
        public string Restrictinchildjoint { get; set; }
        [DisplayName("Do you find any kind of hyper flexibility (more mobile) in the child’s joints?")]
        public string Hyperflexibile { get; set; }

        [DisplayName("Overall body Strength: (YES / NO)")]
        public string Overallstrength { get; set; }

        [DisplayName("Catching: (YES / NO)")]
        public string Catching { get; set; }

        [DisplayName("Balance: (YES / NO)")]
        public string Balance { get; set; }
        [DisplayName("Throwing: (YES / NO)")]
        public string Throwing { get; set; }
        [DisplayName("Jumping on floor: (YES / NO)")]
        public string Jumpingonfloor { get; set; }
        [DisplayName("Clapping: (YES / NO)")]
        public string Clapping { get; set; }
        
        [DisplayName("Negotiating stairs: (YES / NO)")]
        public string Negotiating { get; set; }
        [DisplayName("Jumping from height: (YES / NO)")]
        public string Jumpfromhieght { get; set; }
        [DisplayName("Cycling (Tricycle. bicycle with back supports/bicycle without back supports): (YES / NO)")]
        public string Cycling { get; set; }
        [DisplayName("Standing on one leg: (YES / NO)")]
        public string Standoneleg { get; set; }
        [DisplayName("Kicking: (YES / NO)")]
        public string Kicking { get; set; }
        [DisplayName("Hopping on one leg: (YES / NO)")]
        public string Hopingonleg { get; set; }
        [DisplayName("Does the child feel hot/cold/pain? (YES / NO)")]
        public string Feelhotcoldpain { get; set; }
        [DisplayName("How is the child’s eye hand coordination? (Good/ Satisfactory / zero eye contact)")]
        public string Eyehandcoordination { get; set; }
        [DisplayName("How are the child’s fine hand functions?   (Good/ Satisfactory)/ poor)")]
        public string Handfunction { get; set; }
        [DisplayName("Does the child recognises people around? (YES / NO)")]
        public string Recognizepeople { get; set; }
        [DisplayName("Does the child recognises places around? (YES / NO)")]
        public string Recognizeplace { get; set; }
        [DisplayName("Is the child oriented to time (date/day/month/year)? (YES / NO)")]
        public string Orientedtotime { get; set; }
        [DisplayName("How much is the child’s attention span/concentration? (Good/ Satisfactory/ poor)")]
        public string Attention { get; set; }
        [DisplayName("Is the child easily distracted? (YES / NO)")]
        public string Distraction { get; set; }
        [DisplayName("Does the child remember his Date of birth, what dis he have in dinner last night or breakfast in the morning, his address, contact numbers, etc.? (YES / NO)")]
        public string Rememberdob { get; set; }
        [DisplayName("How good is the child’s command following, give points on the scale of 0-5 (5 as Good to 0 as poor)  ")]
        public string Commandfollow { get; set; }
        [DisplayName("Does the child understand what is being said? (YES / NO)")]
        public string Understandbeforespeak { get; set; }
        [DisplayName("Does the child understand appropriate behaviour in different social situations? (YES / NO)")]
        public string Understandsocialbehaviour { get; set; }
        [DisplayName("Is the child’s vision, ok? (YES / NO)")]
        public string Vision { get; set; }
        [DisplayName("Is the child’s hearing, ok? (YES / NO)")]
        public string Hearing { get; set; }
        [DisplayName("Is the child able to speak? If yes, does he respond in words or phrases or sentences?")]
        public string Abletospeak { get; set; }
        [DisplayName("What is the child’s preferred mode of communication? gestural/verbal")]
        public string Preferredmodeofcom { get; set; }
        [DisplayName("Does the child recognises everything in his environment/understand the spoken language of others? ")]
        public string Understandspokenofother { get; set; }
        [DisplayName("Mathematics: Whether the child can verbalise/write numbers in sequence? Does he/she have the number concept? ")]
        public string Mathematics { get; set; }
        [DisplayName("Alphabet: Whether the child can verbalise/write alphabet in sequence? ")]
        public string Aplhabet { get; set; }
        [DisplayName("Writing: Can a child grip a pencil? ")]
        public string Writing { get; set; }
        [DisplayName("Reading: Does the child know phonic sounds? ")]
        public string Reading { get; set; }
        [DisplayName("Calculations: Is he/she able to do simple calculations? ")]
        public string Calculation { get; set; }
        [DisplayName("Does the child identify common colours? ")]
        public string Identifycommoncolor { get; set; }
        [DisplayName("Does the child identify common shapes? ")]
        public string Identifycommonshape { get; set; }
        [DisplayName("Can he/she perform matching and sorting")]
        public string Identifymatching { get; set; }
        [DisplayName("Can he/she categorize various objects into categories like apple will go into the category of fruits? ")]
        public string Identifycategoryoffruit { get; set; }
        [DisplayName("Is the child able to find out something in a cluttered drawer? ")]
        public string Cluttereddrawer { get; set; }
        [DisplayName("Does the child have the concept of sizes? ")]
        public string Conceptofsize { get; set; }
        [DisplayName("Is the child able to discriminate objects just by looking at them? ")]
        public string Descriminateobject { get; set; }
        [DisplayName("Is the child able to identify objects if only half of the image is shown")]
        public string Identifyimage { get; set; }
        [DisplayName("Is the child able to copy/draw simple geometrical figures?")]
        public string Drawgeometricalfig { get; set; }
        [DisplayName("Is the child able to search for objects in his/her environment?")]
        public string Abletosearchobject { get; set; }
        [DisplayName("Does the child identify Right and left on his own body?")]
        public string Identifyrightandleft { get; set; }
        [DisplayName("Does the child identify all his/her body parts?")]
        public string Identifyallbodypart { get; set; }
        [DisplayName("Is the child able to make and maintain new friends? ")]
        public string Makenewfriend { get; set; }
        [DisplayName("How does a child prefer to play? Alone or in a group")]
        public string Playaloneorgroup { get; set; }
        [DisplayName("Does the child have any behavioural concerns like hitting self or others, pinching, hair pulling, throwing things, lying on the floor, etc.? If yes, please specify the precipitating and calming factors.")]
        public string Hittingself { get; set; }
        [DisplayName("Is the child able to undress/dress himself/herself? ")]
        public string Abletodress { get; set; }
        [DisplayName("Is the child able to feed himself/herself? ")]
        public string Abletofeed { get; set; }
        [DisplayName("Does the child indicate the urge to go to the toilet? How independent is he/she in the task?")]
        public string AbletoToilet { get; set; }
             




    }
}
