﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IPHTickets.Models
{
    public class Email
    {
        [Key]
        public int id { get; set; }
        public string name { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string remarks { get; set; }
        public int status { get; set; }
        public string web { get; set; }
        public DateTime dated { get; set; }
        public string country { get; set; }
        public string state { get; set; }
        public string city { get; set; }
        public DateTime timeend { get; set; }
        public string disease { get; set; }
        public string ipaddress { get; set; }
        public string deletedby { get; set; }
        public string deletedremarks { get; set; }
        public int isencrypt { get; set; }
        public string verfied { get; set; }

    }
}
