﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IPHTickets.Models
{
    public class Isaa
    {
        [Key]
        public int patientid { get; set; }

        [Required]
        [DisplayName("Name of the Child")]
        public string name { get; set; }
        [Required]
        [DisplayName("Bill No.")]
        public string bill { get; set; }

        [Required]
        [DisplayName("Gender")]
        public string gender { get; set; }

        [Required]
        [DisplayName("Date")]
        public DateTime date { get; set; }
        [Required]
        [DisplayName("D.O.B.")]
        public DateTime dob { get; set; }
        [Required]
        [DisplayName("Age")]
        public int Age { get; set; }
        [Required]
        [DisplayName("Examiner")]
        public string exam { get; set; }
        [Required]
        [DisplayName("Has Poor Eye Contact")]
        public string pooreye { get; set; }
        [Required]
        [DisplayName("Lacks Social Smile")]
        public string smile { get; set; }

        [Required]
        [DisplayName("Remains Aloof")]
        public string aloof { get; set; }
        [Required]
        [DisplayName("Does not reach out to others")]
        public string reach { get; set; }
        [Required]
        [DisplayName("Unable to relate to people")]
        public string relate { get; set; }
        [Required]
        [DisplayName("Unable to respond to Social / Environmental Cues")]
        public string respond { get; set; }
        [Required]
        [DisplayName("Engages in solitay and repetitive play activities")]
        public string engage { get; set; }
        [Required]
        [DisplayName("Unable to take turns in Social Interactions")]
        public string turn { get; set; }
        [Required]
        [DisplayName("Does not Maintain Peer Relationships")]
        public string relation { get; set; }
        [Required]
        [DisplayName("Shows inappropriate Emotional Response")]
        public string emotional { get; set; }
        [Required]
        [DisplayName("Shows Exaggerated Emotions")]
        public string exaggerated { get; set; }
        [Required]
        [DisplayName("Engaged in Self-stimulating Emotions")]
        public string stimulate { get; set; }
        [Required]
        [DisplayName("Lacks Fear of Danger")]
        public string fear { get; set; }
        [Required]
        [DisplayName("Excited or Agitated for no Apparent reason")]
        public string agitated { get; set; }
        [Required]
        [DisplayName("Acquired Speech and lost it")]
        public string speech { get; set; }
        [Required]
        [DisplayName("Has Difficulty in using non-verbal language or gestures to communicate?")]
        public string language { get; set; }
        [Required]
        [DisplayName("Engages in Stereotyped and repetitive use of Language")]
        public string streotyped { get; set; }
        [Required]
        [DisplayName("Engages in Eholalic Speech")]
        public string eholalic { get; set; }
        [Required]
        [DisplayName("Produces infantile squeals/ unusual noices")]
        public string squeal { get; set; }
        [Required]
        [DisplayName("Unable to initiate or sustain conversation with Others")]
        public string initiate { get; set; }
        [Required]
        [DisplayName("Uses Jargon or Meaningless words")]
        public string jargon { get; set; }
        [Required]
        [DisplayName("Uses Pronoun Reversals")]
        public string pronoun { get; set; }
        [Required]
        [DisplayName("Unable to grasp pragmatics of Communication")]
        public string grasp { get; set; }
        [Required]
        [DisplayName("Engages in streotyped and repetitive motor mannerisms")]
        public string manner { get; set; }
        [Required]
        [DisplayName("Show attachment to inanimate objects")]
        public string inanimate { get; set; }
        [Required]
        [DisplayName("Shows Hyperactivity / Restlessness")]
        public string hyper { get; set; }
        [Required]
        [DisplayName("Exhibits Aggressive Behavior ")]
        public string behave { get; set; }
        [Required]
        [DisplayName("Throws temper tantrums ")]
        public string temper { get; set; }
        [Required]
        [DisplayName("Engages in self-Injurious Behavior")]
        public string injury { get; set; }
        [Required]
        [DisplayName("Insist on Sameness")]
        public string sameness { get; set; }
       
        [Required]
        [DisplayName("Unusually sensitive to sensory stimuli")]
        public string stimuli { get; set; }
        [Required]
        [DisplayName("Stares into space from Long Period of Time")]
        public string stare { get; set; }

        [Required]
        [DisplayName("Has Difficulty in Tracking Objects")]
        public string difftrack { get; set; }
        [Required]
        [DisplayName("Has Unusual Vision")]
        public string unusual { get; set; }
        [Required]
        [DisplayName("Insensitive to Pain")]
        public string pain { get; set; }
        [Required]
        [DisplayName("Respond to People / Objects usually by smelling , touching and tasting")]
        public string tasting { get; set; }

        [Required]
        [DisplayName("Inconsistent Attention and Concentration")]
        public string inconsistent { get; set; }
        [Required]
        [DisplayName("Shows delay in Responding")]
        public string delay { get; set; }

        [DisplayName("Has unusual  memory of some kind")]
        public string memory { get; set; }
        [Required]
        [DisplayName("Has 'Savant' ability")]
        public string  savant{ get; set; }
        [Required]
        [DisplayName("No Autism < 70")]
        public string noaut { get; set; }
        [Required]
        [DisplayName("Mild Autism 70 to 106")]
        public string mildaut { get; set; }
        [Required]
        [DisplayName("Moderate Autism 107 to 153")]
        public string moderate { get; set; }
        [Required]
        [DisplayName("Severe Autism > 153")]
        public string severe { get; set; }
        [Required]
        [DisplayName("Remarks")]
        public string remark { get; set; }
    }
}
