﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IPHTickets.Models
{
    public class Ticket
    {
        [Key]
        public int ticketid { get; set; }
        public string ticketname { get; set; }
        public string ticketassignid { get; set; }
        public string ticketstatus { get; set; }
        public string ticketdatetime { get; set; }
    }
}
