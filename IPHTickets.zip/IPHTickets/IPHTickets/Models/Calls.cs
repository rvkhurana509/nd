﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IPHTickets.Models
{
    public class Calls
    {
        [Key]
        public int Id { get; set; }
        public string agentphonenumber { get; set; }
        public string disposition { get; set; }
        public string callerconfaudiofile { get; set; }
        public string transferredto { get; set; }
        public string apikey { get; set; }
        public string did { get; set; }
        public string starttime { get; set; }
        public string callduration { get; set; }
        public string endtime { get; set; }
        public string confduration { get; set; }
        public string customerstatus { get; set; }
        public string timetoanswer { get; set; }
        public string monitorucid { get; set; }
        public string agentid { get; set; }
        public string agentstatus { get; set; }
        public string location { get; set; }
        public string fallbackrule { get; set; }
        public string campaignstatus { get; set; }
        public string callerid { get; set; }
        public string duration { get; set; }
        public string status { get; set; }
        public string agentuniqueid { get; set; }
        public string username { get; set; }
        public string hangupby { get; set; }
        public string audiofile { get; set; }
        public string phonename { get; set; }
        public string transfertype { get; set; }

        public string dialstatus { get; set; }
        public string campaignname { get; set; }
        public string uui { get; set; }
        public string agentname { get; set; }
        public string skill { get; set; }
        public string dialednumber { get; set; }
        public string comments { get; set; }
        public string createddate { get; set; }
        public string enq_code { get; set; }
        public string isused { get; set; }

        public string type { get; set; }
        public string vendor { get; set; }
        public string dprid { get; set; }
    }
}
