﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using IPHTickets.Data;
using IPHTickets.Models;

namespace IPHTickets.Controllers
{
    public class IsaasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public IsaasController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Isaas
        public async Task<IActionResult> Index()
        {
            return View(await _context.Isaa.ToListAsync());
        }

        // GET: Isaas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var isaa = await _context.Isaa
                .FirstOrDefaultAsync(m => m.patientid == id);
            if (isaa == null)
            {
                return NotFound();
            }

            return View(isaa);
        }

        // GET: Isaas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Isaas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("patientid,name,bill,gender,date,dob,Age,exam,pooreye,smile,aloof,reach,relate,respond,engage,turn,relation,emotional,exaggerated,stimulate,fear,agitated,speech,language,streotyped,eholalic,squeal,initiate,jargon,pronoun,grasp,manner,inanimate,hyper,behave,temper,injury,sameness,stimuli,stare,difftrack,unusual,pain,tasting,inconsistent,delay,memory,savant,noaut,mildaut,moderate,severe,remark")] Isaa isaa)
        {
            if (ModelState.IsValid)
            {
                _context.Add(isaa);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(isaa);
        }

        // GET: Isaas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var isaa = await _context.Isaa.FindAsync(id);
            if (isaa == null)
            {
                return NotFound();
            }
            return View(isaa);
        }

        // POST: Isaas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("patientid,name,bill,gender,date,dob,Age,exam,pooreye,smile,aloof,reach,relate,respond,engage,turn,relation,emotional,exaggerated,stimulate,fear,agitated,speech,language,streotyped,eholalic,squeal,initiate,jargon,pronoun,grasp,manner,inanimate,hyper,behave,temper,injury,sameness,stimuli,stare,difftrack,unusual,pain,tasting,inconsistent,delay,memory,savant,noaut,mildaut,moderate,severe,remark")] Isaa isaa)
        {
            if (id != isaa.patientid)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(isaa);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!IsaaExists(isaa.patientid))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(isaa);
        }

        // GET: Isaas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var isaa = await _context.Isaa
                .FirstOrDefaultAsync(m => m.patientid == id);
            if (isaa == null)
            {
                return NotFound();
            }

            return View(isaa);
        }

        // POST: Isaas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var isaa = await _context.Isaa.FindAsync(id);
            _context.Isaa.Remove(isaa);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool IsaaExists(int id)
        {
            return _context.Isaa.Any(e => e.patientid == id);
        }
    }
}
