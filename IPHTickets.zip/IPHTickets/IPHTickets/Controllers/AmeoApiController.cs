﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using IPHTickets.Models;
using System.Net.Http;
using Microsoft.AspNetCore.Authorization;

namespace IPHTickets.Controllers
{
    [Authorize]
    public class AmeoApiController : Controller
    {
        public async Task<IActionResult> Index()
        {
            List<AmeoApi> ameoticketList = new List<AmeoApi>();
            using (var httpClient = new HttpClient())
            
                using (var response = await httpClient.GetAsync("http://localhost:49146/api/employee"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                ameoticketList = JsonConvert.DeserializeObject<List<AmeoApi>>(apiResponse);
                }
            return View(ameoticketList);
        }
           
       
    }
   
}


