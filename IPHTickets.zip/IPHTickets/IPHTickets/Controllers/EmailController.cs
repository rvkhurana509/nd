﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using IPHTickets.Models;
using System.Net.Http;
using Microsoft.AspNetCore.Authorization;

namespace IPHTickets.Controllers
{
   [Authorize]
    public class EmailController : Controller
    {
        public async Task<IActionResult> Index()
        {
            List<Email> emailticketList = new List<Email>();
            using (var httpClient = new HttpClient())

            using (var response = await httpClient.GetAsync("http://localhost:49146/api/department"))
            {
                string apiResponse = await response.Content.ReadAsStringAsync();
                emailticketList = JsonConvert.DeserializeObject<List<Email>>(apiResponse);
            }
            return View(emailticketList);
        }

       

      
    }
}
