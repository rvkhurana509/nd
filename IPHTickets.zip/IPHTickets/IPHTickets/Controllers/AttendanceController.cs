﻿using IPHTickets.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace IPHTickets.Controllers
{
    public class AttendanceController : Controller
    {
        public async Task<IActionResult> Index()
        {
            List<Attendance> attendanceList = new List<Attendance>();
            using (var httpClient = new HttpClient())

            using (var response = await httpClient.GetAsync("https://localhost:44396/api/Data"))
            {
                string apiResponse = await response.Content.ReadAsStringAsync();
                attendanceList = JsonConvert.DeserializeObject<List<Attendance>>(apiResponse);
            }
            return View(attendanceList);
        }
    }
}
