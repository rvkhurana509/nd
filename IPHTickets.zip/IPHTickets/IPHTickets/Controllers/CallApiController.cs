﻿using IPHTickets.DTO;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace IPHTickets.Controllers
{
    public class CallApiController : Controller
    {
        public async Task<IActionResult> Index()
        {
            List<CallDTO> callticketList = new List<CallDTO>();
            using (var httpClient = new HttpClient())

            using (var response = await httpClient.GetAsync("http://localhost:49146/api/call"))
            {
                string apiResponse = await response.Content.ReadAsStringAsync();
                callticketList = JsonConvert.DeserializeObject<List<CallDTO>>(apiResponse);
            }
            return View(callticketList);
        }
    }
}
