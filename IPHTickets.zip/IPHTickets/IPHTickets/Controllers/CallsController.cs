﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using IPHTickets.Data;
using IPHTickets.Models;
using Microsoft.AspNetCore.Authorization;

namespace IPHTickets.Controllers
{
    [Authorize]
    public class CallsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CallsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Calls
        public async Task<IActionResult> Index()
        {
            return View(await _context.Calls.ToListAsync());
        }

        // GET: Calls/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var calls = await _context.Calls
                .FirstOrDefaultAsync(m => m.Id == id);
            if (calls == null)
            {
                return NotFound();
            }

            return View(calls);
        }

        // GET: Calls/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Calls/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,agentphonenumber,disposition,callerconfaudiofile,transferredto,apikey,did,starttime,callduration,endtime,confduration,customerstatus,timetoanswer,monitorucid,agentid,agentstatus,location,fallbackrule,campaignstatus,callerid,duration,status,agentuniqueid,username,hangupby,audiofile,phonename,transfertype,dialstatus,campaignname,uui,agentname,skill,dialednumber,comments,createddate,enq_code,isused,type,vendor,dprid")] Calls calls)
        {
            if (ModelState.IsValid)
            {
                _context.Add(calls);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(calls);
        }

        // GET: Calls/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var calls = await _context.Calls.FindAsync(id);
            if (calls == null)
            {
                return NotFound();
            }
            return View(calls);
        }

        // POST: Calls/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,agentphonenumber,disposition,callerconfaudiofile,transferredto,apikey,did,starttime,callduration,endtime,confduration,customerstatus,timetoanswer,monitorucid,agentid,agentstatus,location,fallbackrule,campaignstatus,callerid,duration,status,agentuniqueid,username,hangupby,audiofile,phonename,transfertype,dialstatus,campaignname,uui,agentname,skill,dialednumber,comments,createddate,enq_code,isused,type,vendor,dprid")] Calls calls)
        {
            if (id != calls.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(calls);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CallsExists(calls.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(calls);
        }

        // GET: Calls/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var calls = await _context.Calls
                .FirstOrDefaultAsync(m => m.Id == id);
            if (calls == null)
            {
                return NotFound();
            }

            return View(calls);
        }

        // POST: Calls/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var calls = await _context.Calls.FindAsync(id);
            _context.Calls.Remove(calls);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CallsExists(int id)
        {
            return _context.Calls.Any(e => e.Id == id);
        }
    }
}
