﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using IPHTickets.DTO;
using IPHTickets.Data;

namespace IPHTickets.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CallDTOesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CallDTOesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/CallDTOes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CallDTO>>> GetCallDTO()
        {
            return await _context.CallDTO.ToListAsync();
        }

        // GET: api/CallDTOes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CallDTO>> GetCallDTO(int id)
        {
            var callDTO = await _context.CallDTO.FindAsync(id);

            if (callDTO == null)
            {
                return NotFound();
            }

            return callDTO;
        }

        // PUT: api/CallDTOes/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCallDTO(int id, CallDTO callDTO)
        {
            if (id != callDTO.Id)
            {
                return BadRequest();
            }

            _context.Entry(callDTO).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CallDTOExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CallDTOes
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<CallDTO>> PostCallDTO(CallDTO callDTO)
        {
            _context.CallDTO.Add(callDTO);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCallDTO", new { id = callDTO.Id }, callDTO);
        }

        // DELETE: api/CallDTOes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CallDTO>> DeleteCallDTO(int id)
        {
            var callDTO = await _context.CallDTO.FindAsync(id);
            if (callDTO == null)
            {
                return NotFound();
            }

            _context.CallDTO.Remove(callDTO);
            await _context.SaveChangesAsync();

            return callDTO;
        }

        private bool CallDTOExists(int id)
        {
            return _context.CallDTO.Any(e => e.Id == id);
        }
    }
}
