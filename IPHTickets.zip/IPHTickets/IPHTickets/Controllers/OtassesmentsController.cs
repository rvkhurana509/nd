﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using IPHTickets.Data;
using IPHTickets.Models;
using Microsoft.AspNetCore.Authorization;

namespace IPHTickets.Controllers
{
    [Authorize]
    public class OtassesmentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OtassesmentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Otassesments
        public async Task<IActionResult> Index()
        {
            return View(await _context.Otassesment.ToListAsync());
        }

        // GET: Otassesments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var otassesment = await _context.Otassesment
                .FirstOrDefaultAsync(m => m.FormID == id);
            if (otassesment == null)
            {
                return NotFound();
            }

            return View(otassesment);
        }

        // GET: Otassesments/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Otassesments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FormID,PatientName,BillCode,Age,Sex,Address,DOB,School,Class,Dominance,Diagnosis,DOA,Concern,Birthhistory,WalkSpeak,Medicalconditions,OnMedication,Hospitalizations,Familytype,Profoffather,Profofmother,sibling,Ageofsibling,Schoolofsibling,Primarycaregiver,Historyifpreexist,Anytreatmentearlier,Restrictinchildjoint,Hyperflexibile,Overallstrength,Catching,Balance,Throwing,Jumpingonfloor,Clapping,Negotiating,Jumpfromhieght,Cycling,Standoneleg,Kicking,Hopingonleg,Feelhotcoldpain,Eyehandcoordination,Handfunction,Recognizepeople,Recognizeplace,Orientedtotime,Attention,Distraction,Rememberdob,Commandfollow,Understandbeforespeak,Understandsocialbehaviour,Vision,Hearing,Abletospeak,Preferredmodeofcom,Understandspokenofother,Mathematics,Aplhabet,Writing,Reading,Calculation,Identifycommoncolor,Identifycommonshape,Identifymatching,Identifycategoryoffruit,Cluttereddrawer,Conceptofsize,Descriminateobject,Identifyimage,Drawgeometricalfig,Abletosearchobject,Identifyrightandleft,Identifyallbodypart,Makenewfriend,Playaloneorgroup,Hittingself,Abletodress,Abletofeed,AbletoToilet")] Otassesment otassesment)
        {
            if (ModelState.IsValid)
            {
                _context.Add(otassesment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(otassesment);
        }

        // GET: Otassesments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var otassesment = await _context.Otassesment.FindAsync(id);
            if (otassesment == null)
            {
                return NotFound();
            }
            return View(otassesment);
        }

        // POST: Otassesments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FormID,PatientName,BillCode,Age,Sex,Address,DOB,School,Class,Dominance,Diagnosis,DOA,Concern,Birthhistory,WalkSpeak,Medicalconditions,OnMedication,Hospitalizations,Familytype,Profoffather,Profofmother,sibling,Ageofsibling,Schoolofsibling,Primarycaregiver,Historyifpreexist,Anytreatmentearlier,Restrictinchildjoint,Hyperflexibile,Overallstrength,Catching,Balance,Throwing,Jumpingonfloor,Clapping,Negotiating,Jumpfromhieght,Cycling,Standoneleg,Kicking,Hopingonleg,Feelhotcoldpain,Eyehandcoordination,Handfunction,Recognizepeople,Recognizeplace,Orientedtotime,Attention,Distraction,Rememberdob,Commandfollow,Understandbeforespeak,Understandsocialbehaviour,Vision,Hearing,Abletospeak,Preferredmodeofcom,Understandspokenofother,Mathematics,Aplhabet,Writing,Reading,Calculation,Identifycommoncolor,Identifycommonshape,Identifymatching,Identifycategoryoffruit,Cluttereddrawer,Conceptofsize,Descriminateobject,Identifyimage,Drawgeometricalfig,Abletosearchobject,Identifyrightandleft,Identifyallbodypart,Makenewfriend,Playaloneorgroup,Hittingself,Abletodress,Abletofeed,AbletoToilet")] Otassesment otassesment)
        {
            if (id != otassesment.FormID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(otassesment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OtassesmentExists(otassesment.FormID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(otassesment);
        }

        // GET: Otassesments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var otassesment = await _context.Otassesment
                .FirstOrDefaultAsync(m => m.FormID == id);
            if (otassesment == null)
            {
                return NotFound();
            }

            return View(otassesment);
        }

        // POST: Otassesments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var otassesment = await _context.Otassesment.FindAsync(id);
            _context.Otassesment.Remove(otassesment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OtassesmentExists(int id)
        {
            return _context.Otassesment.Any(e => e.FormID == id);
        }
    }
}
