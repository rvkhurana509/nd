﻿using IPHTickets.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace IPHTickets.Controllers
{
    public class NotcallController : Controller
    {
        public async Task<IActionResult> IndexAsync()
        {
            List<Matured> nocallticketList = new List<Matured>();
            using (var httpClient = new HttpClient())

            using (var response = await httpClient.GetAsync("http://localhost:49146/api/Notcall"))
            {
                string apiResponse = await response.Content.ReadAsStringAsync();
                nocallticketList = JsonConvert.DeserializeObject<List<Matured>>(apiResponse);
            }
            return View(nocallticketList);
        }
    }
}
