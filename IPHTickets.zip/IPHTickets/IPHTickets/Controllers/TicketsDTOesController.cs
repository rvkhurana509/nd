﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using IPHTickets.DTO;
using IPHTickets.Data;

namespace IPHTickets.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TicketsDTOesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TicketsDTOesController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("[action]")]
        [Route("api/TicketsDTOes/Gettickets")]
        // GET: TicketsDTOes
        public async Task<IActionResult> Index()
        {
            return View(await _context.TicketsDTO.ToListAsync());
        }

        [HttpGet]
        [Route("[action]")]
        [Route("api/TicketsDTOes/details")]
        // GET: TicketsDTOes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ticketsDTO = await _context.TicketsDTO
                .FirstOrDefaultAsync(m => m.ticketid == id);
            if (ticketsDTO == null)
            {
                return NotFound();
            }

            return View(ticketsDTO);
        }

        // GET: TicketsDTOes/Create
        [HttpPost]
        [Route("[action]")]
        [Route("api/TicketsDTOes/Createtickets")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: TicketsDTOes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ticketid,ticketname,ticketassignid,ticketstatus,ticketdatetime")] TicketsDTO ticketsDTO)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ticketsDTO);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(ticketsDTO);
        }

        // GET: TicketsDTOes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ticketsDTO = await _context.TicketsDTO.FindAsync(id);
            if (ticketsDTO == null)
            {
                return NotFound();
            }
            return View(ticketsDTO);
        }

        // POST: TicketsDTOes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ticketid,ticketname,ticketassignid,ticketstatus,ticketdatetime")] TicketsDTO ticketsDTO)
        {
            if (id != ticketsDTO.ticketid)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(ticketsDTO);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TicketsDTOExists(ticketsDTO.ticketid))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(ticketsDTO);
        }

        // GET: TicketsDTOes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ticketsDTO = await _context.TicketsDTO
                .FirstOrDefaultAsync(m => m.ticketid == id);
            if (ticketsDTO == null)
            {
                return NotFound();
            }

            return View(ticketsDTO);
        }

        // POST: TicketsDTOes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ticketsDTO = await _context.TicketsDTO.FindAsync(id);
            _context.TicketsDTO.Remove(ticketsDTO);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TicketsDTOExists(int id)
        {
            return _context.TicketsDTO.Any(e => e.ticketid == id);
        }
    }
}
