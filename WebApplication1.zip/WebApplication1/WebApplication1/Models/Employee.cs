﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Employee
    {
        [Key]
        public int id { get; set; }
        public string logid {get; set; }
        public string recipient_id { get; set; }

        public byte issent { get; set; }

        public byte  isdelivered { get; set; }
        public byte isread { get; set; }
        public string text { get; set; }
        public string from { get; set; }
        public string timestamp { get; set; }
        public string type { get; set; }
        public DateTime createddate { get; set; }
        public int enq_code { get; set; }

        public string uid { get; set; }
        public string direction { get; set; }
    }
}
