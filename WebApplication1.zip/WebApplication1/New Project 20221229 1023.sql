-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.33-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema comet
--

CREATE DATABASE IF NOT EXISTS comet;
USE comet;

--
-- Definition of table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment` (
  `appointId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `doctorId` varchar(45) NOT NULL,
  `day` varchar(45) NOT NULL,
  `start` varchar(45) NOT NULL,
  `end` varchar(45) NOT NULL,
  PRIMARY KEY (`appointId`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` (`appointId`,`doctorId`,`day`,`start`,`end`) VALUES 
 (14,'-1','Sunday','12.00 am','12.30 am'),
 (15,'-1','Sunday','12.30 am','01.00 am'),
 (16,'-1','Monday','12.30 am','12.00 am'),
 (17,'-1','Monday','12.30 am','12.30 am'),
 (18,'-1','Monday','12.30 am','12.30 am');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;


--
-- Definition of table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `DepartmentId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DepartmentName` varchar(45) NOT NULL,
  PRIMARY KEY (`DepartmentId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` (`DepartmentId`,`DepartmentName`) VALUES 
 (1,'Pharma'),
 (2,'IT');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;


--
-- Definition of table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `EmployeeId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `EmployeeName` varchar(45) NOT NULL,
  `Department` varchar(45) NOT NULL,
  `DateOfJoining` varchar(45) NOT NULL,
  `PhotoFileName` varchar(45) NOT NULL,
  PRIMARY KEY (`EmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` (`EmployeeId`,`EmployeeName`,`Department`,`DateOfJoining`,`PhotoFileName`) VALUES 
 (1,'Maninder','Pharma','11/2/2022','1'),
 (2,'Love','IT','11/12/2007','1');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `patientid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `patientname` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `paymentstatus` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `enrollmentdate` datetime NOT NULL,
  PRIMARY KEY (`patientid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`patientid`,`patientname`,`address`,`paymentstatus`,`phone`,`enrollmentdate`) VALUES 
 (1,'abc','djgjf','done','895437583','2017-11-01 00:00:00');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
