﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace opd.Data.Migrations
{
    public partial class initials2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "temp",
                columns: table => new
                {
                    temptcode = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ptname = table.Column<string>(nullable: false),
                    phone = table.Column<string>(nullable: false),
                    age = table.Column<int>(nullable: false),
                    amount = table.Column<int>(nullable: false),
                    amountype = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_temp", x => x.temptcode);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "temp");
        }
    }
}
