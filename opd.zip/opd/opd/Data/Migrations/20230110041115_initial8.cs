﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace opd.Data.Migrations
{
    public partial class initial8 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "fifty",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "fivehundred",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "hundred",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ten",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "twenty",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "twohundred",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "twothousand",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "fifty",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "fivehundred",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "hundred",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "ten",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "twenty",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "twohundred",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "twothousand",
                table: "Verfification");
        }
    }
}
