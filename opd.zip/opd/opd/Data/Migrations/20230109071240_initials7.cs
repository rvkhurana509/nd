﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace opd.Data.Migrations
{
    public partial class initials7 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Verfification_temp_amounttemptcode",
                table: "Verfification");

            migrationBuilder.DropForeignKey(
                name: "FK_Verfification_temp_tptcodetemptcode",
                table: "Verfification");

            migrationBuilder.DropIndex(
                name: "IX_Verfification_amounttemptcode",
                table: "Verfification");

            migrationBuilder.DropIndex(
                name: "IX_Verfification_tptcodetemptcode",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "amounttemptcode",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "tptcodetemptcode",
                table: "Verfification");

            migrationBuilder.AddColumn<string>(
                name: "amount",
                table: "Verfification",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "amountype",
                table: "Verfification",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "tptcode",
                table: "Verfification",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "amount",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "amountype",
                table: "Verfification");

            migrationBuilder.DropColumn(
                name: "tptcode",
                table: "Verfification");

            migrationBuilder.AddColumn<int>(
                name: "amounttemptcode",
                table: "Verfification",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "tptcodetemptcode",
                table: "Verfification",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Verfification_amounttemptcode",
                table: "Verfification",
                column: "amounttemptcode");

            migrationBuilder.CreateIndex(
                name: "IX_Verfification_tptcodetemptcode",
                table: "Verfification",
                column: "tptcodetemptcode");

            migrationBuilder.AddForeignKey(
                name: "FK_Verfification_temp_amounttemptcode",
                table: "Verfification",
                column: "amounttemptcode",
                principalTable: "temp",
                principalColumn: "temptcode",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Verfification_temp_tptcodetemptcode",
                table: "Verfification",
                column: "tptcodetemptcode",
                principalTable: "temp",
                principalColumn: "temptcode",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
