﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace opd.Data.Migrations
{
    public partial class initials6 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Verfification",
                columns: table => new
                {
                    verifid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    status = table.Column<string>(nullable: false),
                    tptcodetemptcode = table.Column<int>(nullable: true),
                    temptcode = table.Column<int>(nullable: true),
                    amounttemptcode = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Verfification", x => x.verifid);
                    table.ForeignKey(
                        name: "FK_Verfification_temp_amounttemptcode",
                        column: x => x.amounttemptcode,
                        principalTable: "temp",
                        principalColumn: "temptcode",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Verfification_temp_temptcode",
                        column: x => x.temptcode,
                        principalTable: "temp",
                        principalColumn: "temptcode",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Verfification_temp_tptcodetemptcode",
                        column: x => x.tptcodetemptcode,
                        principalTable: "temp",
                        principalColumn: "temptcode",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Verfification_amounttemptcode",
                table: "Verfification",
                column: "amounttemptcode");

            migrationBuilder.CreateIndex(
                name: "IX_Verfification_temptcode",
                table: "Verfification",
                column: "temptcode");

            migrationBuilder.CreateIndex(
                name: "IX_Verfification_tptcodetemptcode",
                table: "Verfification",
                column: "tptcodetemptcode");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Verfification");
        }
    }
}
