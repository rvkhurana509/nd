﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using opd.Data;
using opd.Models;

namespace opd.Controllers
{
    public class tempsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public tempsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: temps
        public async Task<IActionResult> Index()
        {
            return View(await _context.temp.ToListAsync());
        }

        // GET: temps/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var temp = await _context.temp
                .FirstOrDefaultAsync(m => m.temptcode == id);
            if (temp == null)
            {
                return NotFound();
            }

            return View(temp);
        }

        // GET: temps/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: temps/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("temptcode,tptcode,ptcode,ptname,phone,age,amount,amountype")] temp temp)
        {
            if (ModelState.IsValid)
            {
                _context.Add(temp);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(temp);
        }

        // GET: temps/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var temp = await _context.temp.FindAsync(id);
            if (temp == null)
            {
                return NotFound();
            }
            return View(temp);
        }

        // POST: temps/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("temptcode,tptcode,ptcode,ptname,phone,age,amount,amountype")] temp temp)
        {
            if (id != temp.temptcode)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(temp);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!tempExists(temp.temptcode))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(temp);
        }

        // GET: temps/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var temp = await _context.temp
                .FirstOrDefaultAsync(m => m.temptcode == id);
            if (temp == null)
            {
                return NotFound();
            }

            return View(temp);
        }

        // POST: temps/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var temp = await _context.temp.FindAsync(id);
            _context.temp.Remove(temp);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool tempExists(int id)
        {
            return _context.temp.Any(e => e.temptcode == id);
        }
    }
}
