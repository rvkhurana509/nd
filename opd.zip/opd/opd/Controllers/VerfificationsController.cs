﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using opd.Data;
using opd.Models;

namespace opd.Controllers
{
    public class VerfificationsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VerfificationsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Verfifications
        public async Task<IActionResult> Index()
        {
            return View(await _context.Verfification.ToListAsync());
        }

        // GET: Verfifications/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var verfification = await _context.Verfification
                .FirstOrDefaultAsync(m => m.verifid == id);
            if (verfification == null)
            {
                return NotFound();
            }

            return View(verfification);
        }

        // GET: Verfifications/Create
        public IActionResult Create()
        {
            List<SelectListItem> ddlCateitems = new List<SelectListItem>();
            List<SelectListItem> ddlmanuitems = new List<SelectListItem>();
            ddlCateitems.Add(new SelectListItem() { Selected = true, Text = "--Select--", Value = "-1" });
            _context.temp.ToList().ForEach(x =>
            {
                SelectListItem item = new SelectListItem();
                item.Text = x.ptname +" "+ "Pt.Code"+ x.tptcode + " " + "Amount Type" + x.amountype + " " + "Rs." + x.amount;
                item.Value = x.tptcode.ToString();
               
                ddlCateitems.Add(item);
            });


            TempData["CateListItems"] = ddlCateitems;
                      
            return View();
        }

        // POST: Verfifications/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("verifid,status,tptcode,amount,amountype,twothousand,fivehundred,twohundred,hundred,fifty,twenty,ten")] Verfification verfification)
        {
            if (ModelState.IsValid)
            {
                _context.Add(verfification);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(verfification);
        }

        // GET: Verfifications/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var verfification = await _context.Verfification.FindAsync(id);
            if (verfification == null)
            {
                return NotFound();
            }
            return View(verfification);
        }

        // POST: Verfifications/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("verifid,status,tptcode,amount,amountype,twothousand,fivehundred,twohundred,hundred,fifty,twenty,ten")] Verfification verfification)
        {
            if (id != verfification.verifid)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(verfification);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VerfificationExists(verfification.verifid))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(verfification);
        }

        // GET: Verfifications/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var verfification = await _context.Verfification
                .FirstOrDefaultAsync(m => m.verifid == id);
            if (verfification == null)
            {
                return NotFound();
            }

            return View(verfification);
        }

        // POST: Verfifications/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var verfification = await _context.Verfification.FindAsync(id);
            _context.Verfification.Remove(verfification);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VerfificationExists(int id)
        {
            return _context.Verfification.Any(e => e.verifid == id);
        }
    }
}
