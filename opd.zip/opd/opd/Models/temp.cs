﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace opd.Models
{
    public class temp
    {
        [Key]

      
        public int temptcode { get; set; }
        [DisplayName("Temporary Patient Code")]

        [Required]
        public int tptcode { get; set; }

        [DisplayName("Existing Patient Code")]

        public int ptcode { get; set; }

        [DisplayName("Patient Name")]
        [Required]
        public string ptname { get; set; }

        [DisplayName("Phone")]
        [Required]
        public string phone { get; set; }

        [DisplayName("Age")]
        [Required]
        public int age { get; set; }

        [DisplayName("Amount")]
        [Required]
        public int amount { get; set; }

        [DisplayName("Amount Type")]
        [Required]
        public string amountype { get; set; }

        public List<Verfification> Verfification { get; set; }

    }
}
