﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace opd.Models
{
    public class Verfification
    {
        [Key]
        public int verifid { get; set; }

        [DisplayName("Verfication Status")]
        [Required]
        public string status { get; set; }

        [DisplayName("Tempoarary Patient Code")]
       
        public int tptcode { get; set; }

       

        [DisplayName("Amount Received")]
        
        public string amount { get; set; }

        [DisplayName("Amount Type")]
        public string amountype { get; set; }

        public temp temp { get; set; }

        [DisplayName("2000 Note")]
        public int twothousand { get; set; }

        [DisplayName("500 Note")]
        public int fivehundred { get; set; }

        [DisplayName("200 Note")]
        public int twohundred{ get; set; }

        [DisplayName("100 Note")]
        public int hundred { get; set; }
        [DisplayName("50 Note")]
        public int fifty { get; set; }

        [DisplayName("20 Note")]
        public int twenty { get; set; }

        [DisplayName("10 Note")]
        
        public int ten { get; set; }

    }
}
