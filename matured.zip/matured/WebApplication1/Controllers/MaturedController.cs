﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MaturedController : ControllerBase
    {
        MySqlConnection cn;
        
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _env;

        public MaturedController(IConfiguration configuration, IWebHostEnvironment env)
        {
            _configuration = configuration;
            _env = env;
        }
       
        MySqlConnection con = new MySqlConnection("Data Source = localhost; Initial Catalog = crm_live; User Id = root; password=Nirogam123#;port=3306;pooling=false;sslMode=none;");
        [HttpGet]
        public JsonResult Get()
        {
            //select DISTINCT(enq_code), createddate, logid from admin_ameo.whatsapplog where date(createddate) = DATE(NOW() - INTERVAL 1 DAY) and date(createddate) -interval 60 minute <= now(); ";
            //string query = @"
            //            SELECT * FROM crm_live.enq_rec  where dated > NOW()- interval 3 day and (remarks = null or  remarks= 'na' or remarks =''  or remarks= '....')";

            string query = @"SELECT m.enq_code,m.patient_name,r.dated FROM enq_mas m
 left join enq_rec r on m.enq_code=r.enq_code
where m.enq_date>'2022-09-25' and r.dated<'2022-12-27' and user_status= 'matured';";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            MySqlDataReader myReader;
            using (MySqlConnection mycon = new MySqlConnection(sqlDataSource))
            {
                mycon.Open();
                using (MySqlCommand myCommand = new MySqlCommand(query, mycon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    mycon.Close();
                }
            }

            return new JsonResult(table);
        }

    }
}
