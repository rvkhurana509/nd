﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CallapiController : ControllerBase
    {

        private readonly IConfiguration _configuration;
        public CallapiController(IConfiguration configuration)
        {

            var conn = new MySqlConnection("Data Source=localhost;Initial Catalog=comet;User Id=root;password=Nirogam123#;port=3306;pooling=false;sslMode=none;");
            
        }

        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
                        select patientid,patientname,paymentstatus,phone from 
                        dbo.user
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("conn");
            MySqlDataReader myReader;
            using (MySqlConnection conn = new MySqlConnection(sqlDataSource))
            {
                
                conn.Open();
                using (MySqlCommand myCommand = new MySqlCommand(query, conn))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    conn.Close();
                }
            }

            return new JsonResult(table);
        }

    }
}
